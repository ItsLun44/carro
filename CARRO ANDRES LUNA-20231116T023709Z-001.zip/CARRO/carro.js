var carro = document.querySelector('.carro')
var llanta_1 = document.querySelector('.llanta_1')
var llanta_2 = document.querySelector('.llanta_2')
var fondo = document.querySelector('.fondo')
var polvo = document.querySelector('.polvo')
var oculto = document.querySelector('.oculto')

carro.addEventListener('click', move_all)

function move_all(){
    fondo.classList.add('FondoMovimiento')
    llanta_1.classList.add('Llanta1Movimiento')
    llanta_2.classList.add('Llanta2Movimiento')
    polvo.classList.add('PolvoMovimiento')
    oculto.classList.remove('oculto')
}

